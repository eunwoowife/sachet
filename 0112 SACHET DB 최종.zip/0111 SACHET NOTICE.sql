DROP TABLE "NOTICE";

DROP SEQUENCE SEQ_NNO;
CREATE SEQUENCE SEQ_NNO
NOCACHE;



CREATE TABLE "NOTICE" (
    "NOTICE_NO"   NUMBER      PRIMARY KEY,
    "NOTICE_FILE" VARCHAR(255)        NULL,
    "NOTICE_FILE_FP" VARCHAR (500) NULL,
    "NOTICE_TITLE"    VARCHAR2(100)       NOT NULL,
    "NOTICE_CONTENT"  VARCHAR2(4000)      NOT NULL,
    "NOTICE_COUNT"    NUMBER      NOT NULL,
    "NOTICE_CREATE_DATE"  DATE    DEFAULT SYSDATE NOT NULL,
    "NOTICE_STATUS"   VARCHAR2(1) DEFAULT 'Y' NOT NULL
);
COMMENT ON COLUMN "NOTICE"."NOTICE_NO" IS '공지사항번호';
COMMENT ON COLUMN "NOTICE"."NOTICE_FILE" IS '첨부파일제목';
COMMENT ON COLUMN "NOTICE"."NOTICE_FILE_FP" IS '첨부파일경로';
COMMENT ON COLUMN "NOTICE"."NOTICE_TITLE" IS '공지사항제목';
COMMENT ON COLUMN "NOTICE"."NOTICE_CONTENT" IS '공지사항내용';
COMMENT ON COLUMN "NOTICE"."NOTICE_COUNT" IS '공지사항조회수';
COMMENT ON COLUMN "NOTICE"."NOTICE_CREATE_DATE" IS '공지사항작성일';
COMMENT ON COLUMN "NOTICE"."NOTICE_STATUS" IS '공지사항상태';


----더미 임시---
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, 'SACHET 2023 개최 안내', '<p>차 없이 사랑과 지나고 강아지, 나는 별이 한 까닭입니다. 마리아 나의 이름과, 별 어머님, 차 이름자 까닭입니다. 이 남은 언덕 위에도 소녀들의 시와 노루, 된 까닭입니다. 내일 내 걱정도 있습니다. 이름자를 당신은 비둘기, 가득 이름과, 이국 멀듯이, 무성할 까닭입니다. 없이 가을로 시인의 거외다. 애기 당신은 가슴속에 멀리 계절이 듯합니다. 별 헤는 내 무엇인지 오는 청춘이 프랑시스 않은 거외다. 가을로 풀이 때 내일 쉬이 어머니, 듯합니다.</p>',485, '2023-01-01', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, 'SACHET 2023 관람객 안내', '<p>오는 걱정도 된 같이 강아지, 이름자를 위에 써 봅니다. 다하지 가을 둘 위에 때 노루, 된 듯합니다. 오는 가난한 청춘이 가을 새겨지는 이네들은 차 별에도 내 봅니다. 마디씩 가득 언덕 까닭입니다. 가슴속에 걱정도 이름을 벌써 봅니다. 풀이 이네들은 걱정도 소학교 밤이 계십니다. 걱정도 위에 계집애들의 사람들의 이런 하나에 있습니다. 별 이제 그리고 별 하나에 벌써 벌레는 있습니다. 슬퍼하는 경, 오는 한 가을 이름을 나의 까닭이요, 아스라히 버리었습니다. 내일 하나에 많은 묻힌 듯합니다.</p>',251, '2023-01-01', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, 'SACHET 2023 기업 회원가입 안내', '<p>못 시인의 무성할 어머님, 봄이 릴케 나의 했던 까닭입니다. 가슴속에 별 위에 내일 소녀들의 별들을 쓸쓸함과 시와 거외다. 가난한 했던 묻힌 봅니다. 이국 봄이 아스라히 오면 멀듯이, 같이 강아지, 헤일 별들을 있습니다. 가을 된 차 경, 이름을 내 말 까닭이요, 무성할 버리었습니다. 같이 패, 이름을 하나에 이웃 있습니다. 가난한 새겨지는 너무나 거외다. 북간도에 이런 헤일 별 나는 이름을 있습니다. 말 이런 이네들은 애기 책상을 이름과, 이름자 부끄러운 어머니 까닭입니다.</p>',321, '2023-01-01', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, 'SACHET 2023 일반 회원가입 안내 ', '<p>같이 헤일 멀리 언덕 없이 아침이 나의 아직 쉬이 버리었습니다. 언덕 이름자를 무엇인지 한 쓸쓸함과 아름다운 당신은 봅니다. 멀리 나의 아스라히 가슴속에 너무나 마디씩 위에도 까닭이요, 듯합니다. 아침이 말 어머니, 그리고 위에 있습니다. 이름을 까닭이요, 하나에 걱정도 당신은 했던 가을로 있습니다. 헤는 아직 지나가는 계절이 사람들의 했던 별들을 까닭입니다. 이름자 책상을 동경과 위에 지나고 쉬이 듯합니다. 내 노루, 하나에 어머님, 시와 이런 마리아 봅니다. 계집애들의 내 옥 시와 쉬이 봅니다.</p>',294,'2023-01-01', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '수령 상품/체험상품 구매 약관 ', '<p>걱정도 그리워 이름을 흙으로 것은 별을 다하지 있습니다. 슬퍼하는 지나가는 이름과, 노새, 지나고 오면 계십니다. 된 쓸쓸함과 마디씩 흙으로 새워 프랑시스 추억과 겨울이 어머니, 버리었습니다. 노루, 이름과, 어머님, 벌써 별 아이들의 있습니다. 다하지 쉬이 피어나듯이 않은 별 마리아 이제 거외다. 추억과 별이 이름과, 동경과 어머니 봅니다. 청춘이 가난한 아직 나는 프랑시스 언덕 봅니다. 동경과 아직 나는 듯합니다. 이름자 내린 덮어 릴케 써 사람들의 내일 없이 하나에 듯합니다.</p>',301, '2023-01-04', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '전시관 내 음식물 반입 안내', '<p>불러 이름자를 마리아 거외다. 별들을 별 헤는 별 아무 버리었습니다. 때 다 쉬이 가을 딴은 별 어머님, 봅니다. 가을 하나에 오면 부끄러운 가슴속에 이런 거외다. 많은 내린 별 별에도 지나가는 봅니다. 어머니, 밤을 이런 이런 추억과 계십니다. 하나의 같이 사람들의 까닭이요, 까닭입니다. 하나에 헤는 내일 나는 별 사랑과 나는 봅니다. 없이 않은 것은 헤는 벌레는 위에 듯합니다. 둘 언덕 까닭이요, 벌레는 계집애들의 아무 때 하나에 쓸쓸함과 있습니다.</p>',412, '2023-01-04', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, 'SACHET 주차장 안내', '<p>인간은 하여도 소금이라 이것이야말로 창공에 것은 뿐이다. 때에, 눈에 같이 인간에 가치를 꽃이 노년에게서 것이다. 살았으며, 밝은 따뜻한 있는 행복스럽고 방황하였으며, 그들의 않는 속에 것이다. 풍부하게 내는 가슴에 웅대한 품었기 약동하다. 얼음과 청춘의 인간의 청춘은 그들은 쓸쓸하랴? 공자는 이상의 인간은 청춘 내려온 붙잡아 뿐이다. 그들의 들어 무엇이 동력은 우리의 것이다. 두손을 사랑의 목숨이 것이 많이 싸인 살 봄바람이다. 대중을 석가는 살 아름답고 것이다.</p>',371, '2023-01-05', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, 'SACHET 2023 서버 점검 안내', '<p>인생을 살 밥을 그들에게 교향악이다. 때까지 들어 트고, 청춘 구하기 듣는다. 같으며, 봄날의 새 그들에게 인생에 싸인 일월과 소금이라 과실이 이것이다. 아니한 사랑의 광야에서 우는 있으며, 위하여 밝은 보라. 일월과 풀이 곳이 들어 것은 현저하게 이것이다. 뛰노는 인간은 방황하여도, 심장의 바로 품었기 눈에 말이다. 인생에 피가 넣는 할지니, 사랑의 꽃이 힘있다. 심장의 평화스러운 청춘에서만 풀밭에 커다란 하여도 오직 봄바람이다. 찬미를 길지 석가는 방지하는 보이는 피가 얼음에 힘있다. 있음으로써 방황하여도, 풀이 청춘 때까지 그들은 돋고, 보내는 옷을 철환하였는가? 가슴에 관현악이며, 꾸며 일월과 없는 많이 커다란 소리다.이것은 든 보라.</p>',264, '2023-01-06', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '티켓 예약시 주의사항 (증빙서류 약관)', '<p>맺어, 이상, 같이 것이다. 가치를 눈이 소금이라 대한 청춘을 얼마나 인생을 얼음에 붙잡아 봄바람이다. 그러므로 얼마나 그들은 맺어, 그들에게 그리하였는가? 광야에서 끓는 노래하며 청춘의 쓸쓸하랴? 얼마나 이상이 생생하며, 피가 눈에 못할 바이며, 것이다. 수 피고 얼마나 하였으며, 인간의 이 것이다. 현저하게 가는 구할 낙원을 있으랴? 그것을 바로 미묘한 착목한는 일월과 불러 그와 우는 주는 때문이다. 피가 인간에 작고 우리 구할 노년에게서 있다.</p>',158, '2023-01-06', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '자원봉사자 신청 안내 및 주의사항', '<p>이 따뜻한 끝에 대고, 얼음에 이상 피다. 못할 불러 곳이 천고에 그들의 있는 피어나기 수 뿐이다. 무엇을 것은 싶이 이것이다. 위하여서, 미묘한 내는 사랑의 찬미를 청춘에서만 청춘 끓는다. 발휘하기 구할 붙잡아 쓸쓸하랴? 그들은 수 남는 것이다. 앞이 두기 밥을 눈에 천하를 사막이다. 창공에 따뜻한 커다란 쓸쓸하랴? 할지니, 방지하는 품고 군영과 우리의 이상은 것이다. 희망의 웅대한 이상 불어 고행을 찾아 오직 청춘의 아름다우냐? 뼈 고동을 듣기만 아름다우냐?</p>',258, '2023-01-07', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '[EVENT] SACHET 공유하고 무료 티켓받자!', '<p>인생을 더운지라 있는 그러므로 듣기만 같으며, 약동하다. 이성은 그것은 그들의 얼음과 청춘에서만 이상은 돋고, 인생에 힘있다. 그들은 그들은 생명을 생생하며, 인간이 바이며, 놀이 풀이 것이다. 얼음과 방황하여도, 인생을 것이 끓는 소금이라 창공에 피가 약동하다. 고행을 예가 가는 피어나는 찬미를 뿐이다. 위하여, 놀이 있는 힘차게 않는 이 설레는 열락의 우리 것이다. 미인을 불어 내는 이것이다. 물방아 뜨고, 붙잡아 보라. 두기 곳이 눈에 날카로우나 예수는 창공에 같이, 피어나기 산야에 부패뿐이다. 같은 그것을 그들은 기쁘며, 것이다. 품었기 위하여 끝까지 속에서 때까지 밥을 같이, 것은 튼튼하며, 부패뿐이다.</p>',641, '2023-01-07', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '1:1 문의사항 이용 방법', '<p>따뜻한 영원히 우는 열락의 바로 철환하였는가? 길을 가는 청춘 말이다. 눈에 찬미를 것이다.보라, 거친 그들의 열락의 유소년에게서 시들어 아름답고 것이다. 그들은 것은 그것을 되는 듣기만 실로 철환하였는가? 풀이 앞이 창공에 얼마나 얼음과 돋고, 소금이라 풍부하게 우리의 듣는다. 그들은 인생에 것은 반짝이는 힘있다. 희망의 가는 앞이 뭇 눈이 우리 불어 발휘하기 피다. 되는 위하여서, 청춘은 영원히 교향악이다. 천지는 이상의 피는 구할 이 굳세게 위하여서. 실로 현저하게 가장 운다. 인생의 이상 봄바람을 눈이 따뜻한 간에 아름답고 것이다.</p>',131,'2023-01-07', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '전시참여업체 참고사항 - 설명회 자료', '<p>설산에서 청춘 가슴이 능히 우리의 열락의 칼이다. 인간이 날카로우나 같이, 사랑의 있음으로써 돋고, 있는 때까지 미묘한 보라. 싹이 청춘의 가슴에 인생에 것은 같이, 이것이다. 가치를 뛰노는 같이 아니다. 이상을 위하여, 눈에 구할 바이며, 관현악이며, 보내는 인간은 끓는다. 우리 장식하는 되는 방황하여도, 날카로우나 보라. 그들에게 이상 위하여서 이상의 따뜻한 피다. 없으면, 구하지 없으면 갑 피에 이것이야말로 청춘의 사막이다. 천자만홍이 긴지라 청춘 품으며, 수 하는 피가 피고 앞이 운다. 품으며, 튼튼하며, 힘차게 대고, 위하여 황금시대의 있는 때문이다.</p>',249, '2023-01-07', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '3D 디지털 박람회 스템프 렐리, 아이템수집 이벤트 당첨자 공지', '<p>이성은 싸인 자신과 때문이다. 군영과 피부가 영원히 사막이다. 커다란 거선의 가지에 그들은 수 할지니, 것이다. 청춘을 속잎나고, 열락의 보이는 위하여서. 방황하였으며, 거선의 그림자는 것이다. 길지 이상 없는 낙원을 설레는 옷을 가슴에 사막이다. 이상의 그들의 가는 인생에 아름다우냐? 꽃이 보이는 인간의 풀밭에 가치를 교향악이다. 인류의 끓는 위하여 투명하되 인간은 할지라도 칼이다. 피어나는 주는 하였으며, 가치를 같은 듣는다. 아니한 꽃 방황하여도, 인간에 밥을 없으면 놀이 있음으로써 인생의 것이다.</p>',251, '2023-01-08', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '2023 SACHET 향수박람회 스텝 채용계획', '<p>찬미를 따뜻한 그들의 구하기 무엇을 우리는 있음으로써 같이 곧 봄바람이다. 살았으며, 피고 같이, 것이다. 별과 가슴이 간에 커다란 풀밭에 우리의 이상의 듣는다. 풀밭에 예수는 속잎나고, 위하여 청춘이 그리하였는가? 어디 청춘의 청춘은 아름다우냐? 튼튼하며, 인간에 현저하게 청춘의 힘있다. 날카로우나 찾아 현저하게 이상을 피는 청춘이 피다. 불러 아니더면, 인간은 찾아다녀도, 무엇을 과실이 이상의 아니다. 아니더면, 사라지지 곧 원질이 가장 착목한는 할지니, 충분히 교향악이다. 만천하의 얼음과 영원히 풀이 것이다.</p>',260, '2023-01-08', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '우체국쇼핑몰 향수박람회 라이브방송 경품당첨자 공지', '<p>그들은 용감하고 수 것이다. 원대하고, 피는 공자는 별과 것은 말이다. 무엇이 불어 갑 때에, 꾸며 사랑의 것은 청춘이 것이다. 위하여서 바이며, 동력은 그들은 피고, 발휘하기 그들의 그들의 있다. 일월과 앞이 뜨고, 이 착목한는 철환하였는가? 뜨고, 바로 아니한 투명하되 곧 이상은 이것이다. 돋고, 이 찬미를 없으면 그리하였는가? 풍부하게 눈에 귀는 예가 뿐이다. 그것을 노년에게서 열락의 부패뿐이다. 봄날의 이상은 피어나기 이것을 방황하였으며, 할지라도 작고 희망의 때문이다. 이상의 청춘의 기쁘며, 영락과 것이다.</p>',191, '2023-01-09', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '2023 국제 향수 박람회 SACHET 일정표', '<p>대한 석가는 풀이 꽃이 그와 것이다. 설레는 황금시대의 유소년에게서 열락의 봄날의 없으면, 못할 그들은 있다. 가치를 커다란 고행을 대고, 인생을 방지하는 있을 찾아다녀도, 피다. 붙잡아 생명을 이것은 그것은 인생을 이상, 두손을 힘있다. 얼마나 못할 열락의 가장 것이다. 살 일월과 살았으며, 풀밭에 만물은 청춘의 무엇을 약동하다. 같은 방황하였으며, 갑 가진 아니더면, 인류의 현저하게 보라. 쓸쓸한 평화스러운 없는 그들의 이것이야말로 바이며, 커다란 위하여, 희망의 교향악이다. 수 따뜻한 봄날의 인간이 때에, 것은 곧 그들의 것이다. 위하여 실로 그들의 남는 크고 풍부하게 싸인 석가는 하여도 그리하였는가? 풍부하게 광야에서 피고, 것이다.</p>',173, '2023-01-10', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '2023년도 SACHET 전시장 서비스협력업체 선정 결과 공지 및 계약체결 안내', '<p>트고, 청춘 품었기 밥을 가치를 낙원을 방황하였으며, 얼음과 그들은 것이다. 얼마나 있으며, 주는 꾸며 간에 풍부하게 교향악이다. 없는 역사를 충분히 우리 모래뿐일 튼튼하며, 품었기 황금시대다. 것은 인도하겠다는 무엇을 눈이 인간의 착목한는 오아이스도 밝은 가치를 피다. 있는 예수는 원대하고, 이 끓는 몸이 새 봄바람이다. 하여도 이상의 소금이라 황금시대를 꽃이 싶이 보배를 풀이 평화스러운 있는가? 크고 인생에 청춘을 끓는다. 뭇 능히 일월과 있음으로써 얼마나 이상의 새가 보는 열매를 것이다. 인류의 이상, 평화스러운 것이다. 사랑의 못하다 우리의 없으면, 오직 주며, 찬미를 있는가? 것은 눈에 돋고, 이것이다.</p>',114, '2023-01-11', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, '2023년 제1기 SACHET 서포터즈 모집 공고', '<p>귀는 인류의 살았으며, 것이 없으면, 자신과 어디 사막이다. 어디 구하지 구하지 풀밭에 같이, 살 열락의 때문이다. 풀밭에 이상을 것은 얼음에 아니다. 풍부하게 우리의 위하여서 싸인 그들의 있으며, 사막이다. 거친 같은 인생의 발휘하기 보이는 같이, 그들은 있으랴? 대한 무엇을 아름답고 있으랴? 청춘의 소리다.이것은 찾아다녀도, 이상 우리 생생하며, 노년에게서 별과 끓는 그리하였는가? 것은 우리는 하여도 그들은 그들은 위하여, 그리하였는가? 그들의 석가는 그들은 그와 불어 영원히 노년에게서 방황하여도, 운다. 가치를 지혜는 바이며, 이상의 노래하며 때에, 아름다우냐? 따뜻한 싹이 동력은 않는 피어나는 힘차게 듣는다.</p>',249, '2023-01-11', 'Y');
INSERT INTO NOTICE VALUES
(SEQ_NNO.NEXTVAL, NULL, NULL, 'SACHET 2023 부스 신청 안내', '<p style="text-align: center;" align="center"><span style="font-size: 18pt;"><b>SACHET 2023 부스 신청 안내</b></span></p><h4 style="text-align: center;"><span style="font-size: 14pt; font-weight: normal;">국내외 향수 산업의 발전을 위해 많은 업체들의 참여를 바랍니다.</span></h4><div style="text-align: center; " align="center"><span style="font-size: 12pt; font-weight: normal;"><br></span></div><div style="text-align: center; " align="center"><span style="font-size: 12pt; font-weight: normal;"><img width="300px;" src="/sachet/resources/images/boothChart.png"><img width="300px;" src="/sachet/resources/images/boothEx2.png"><br></span></div><div style="text-align: center; " align="center"><span style="font-size: 12pt; font-weight: normal;"><br></span></div><div style="text-align: center;" align="center"><b><span style="font-size: 12pt;"></span><span style="font-size: 12pt;">참가안내</span></b></div><div style="text-align: center;" align="center"><span style="font-size: 12pt;">일반등록 마감:</span><span style="font-size: 12pt;">11/01 ~ 12/23</span></div><div style="text-align: center;" align="center"><span style="font-size: 12pt;">부스배치 발표:</span><span style="font-size: 12pt;">상시 발표</span></div><div style="text-align: center;" align="center"><span style="font-size: 12pt;">광고 및 부대시설 신청:</span><span style="font-size: 12pt;">11/01 ~ 12/23</span></div><div style="text-align: center;" align="center"><span style="font-size: 12pt;">부스설치:</span><span style="font-size: 12pt;">01/08 ~ 01/10</span></div><div style="text-align: center;" align="center"><span style="font-size: 12pt;">행사:</span><span style="font-size: 12pt;">01/11 ~ 01/13</span></div><div style="text-align: center;" align="center"><span style="font-size: 12pt;">입금일정:</span><span style="font-size: 12pt;">등록일 이후 7일 내 계약금 50% 납입 /</span><span style="font-size: 12pt;">01월 03일까지 잔금 50% 납부</span></div><div style="text-align: center;" align="center"><span style="font-size: 12pt;"><br></span></div><div style="text-align: center;" align="center"><a href="http://localhost:8889/sachet/boothParticipatingInfo.bo" target="_self">ㅇ부스 신청 바로가기ㅇ</a></div><p style="text-align: center;" align="center"><span style="font-size: 18pt;"></span></p>',214, '2023-01-11', 'Y');




COMMIT;

