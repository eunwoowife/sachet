-------------------------------------------------BOOTH TABLE START------------------------------------------------------------
-----------------221226 BOOTH_STATUS 부스승인상태 추가
-----------------230104 YVES SAINT LAURENT 부스섹션 바꿈
-----------------230105 부스신청일 컬럼 추가
-----------------230105 CELINE 부스가격 바꿈
DROP TABLE BOOTH CASCADE CONSTRAINTS;
DROP SEQUENCE SEQ_BTNO;

CREATE SEQUENCE SEQ_BTNO
NOCACHE;

CREATE TABLE BOOTH(
	BOOTH_NO	NUMBER		PRIMARY KEY,
	COM_NO	NUMBER		NOT NULL,
	BOOTH_NAME	VARCHAR2(100)	NOT NULL UNIQUE,
	BOOTH_DETAIL	VARCHAR2(4000)		NOT NULL,
	BOOTH_IMG_ON	VARCHAR2(200)		NOT NULL,
	BOOTH_IMG_FP	VARCHAR2(500)		NOT NULL,
	BOOTH_PRICE	NUMBER	DEFAULT 1	NOT NULL,
	BOOTH_SECTION	NUMBER		NOT NULL,
    BOOTH_STATUS VARCHAR2(1)	DEFAULT 'N'	NOT NULL,
    REPORTING_DATE DATE DEFAULT SYSDATE NOT NULL,
FOREIGN KEY (COM_NO) REFERENCES COMPANY (USER_NO)
);

--코멘트 추가
COMMENT ON COLUMN "BOOTH"."BOOTH_NO" IS '부스고유번호';
COMMENT ON COLUMN "BOOTH"."COM_NO" IS '기업번호';
COMMENT ON COLUMN "BOOTH"."BOOTH_NAME" IS '부스이름';
COMMENT ON COLUMN "BOOTH"."BOOTH_DETAIL" IS '부스설명';
COMMENT ON COLUMN "BOOTH"."BOOTH_IMG_ON" IS '부스썸네일 파일 원본명';
COMMENT ON COLUMN "BOOTH"."BOOTH_IMG_FP" IS '부스썸네일 파일 경로';
COMMENT ON COLUMN "BOOTH"."BOOTH_PRICE" IS '부스가격';
COMMENT ON COLUMN "BOOTH"."BOOTH_SECTION" IS '부스위치';
COMMENT ON COLUMN "BOOTH"."BOOTH_STATUS" IS '부스승인상태(N부스신청/Y승인완료/P결제완료/J부스심사/D승인거절)';
COMMENT ON COLUMN "BOOTH"."REPORTING_DATE" IS '부스신청일';

-- 더미 데이터 추가
INSERT INTO BOOTH VALUES (SEQ_BTNO.NEXTVAL, 1, 'JOMALONE', '런던에서 온 부티크 향수 앤 라이프 스타일 브랜드', 'jo1.jpg','resources/uploadFiles/jo1.jpg', 3, 1, 'Y', SYSDATE);
INSERT INTO BOOTH VALUES (SEQ_BTNO.NEXTVAL, 2, 'LOUIS VUITTON', '루이비통은 따스한 빛과 부드럽게 에워싸는 몰입감이 조화를 이루는 향의 교향악을 우리에게 선사합니다.', 'louis1.jpg','resources/uploadFiles/louis1.jpg', 3, 2, 'Y', SYSDATE);
INSERT INTO BOOTH VALUES (SEQ_BTNO.NEXTVAL, 3, 'CELINE', '셀린느 오뜨 퍼퓨머리 컬렉션은 성별의 경계를 허무는 에디 슬리먼의 스타일 코드를 향기에 담아냈습니다.', 'cel1.jpg','resources/uploadFiles/cel1.jpg', 3, 3, 'Y', SYSDATE);
INSERT INTO BOOTH VALUES (SEQ_BTNO.NEXTVAL, 4, 'YVES SAINT LAURENT', '그 어느때보다 뜨거운 자유를 담은 퍼퓸을 만나보세요.', 'ysl1.jpg','resources/uploadFiles/ysl1.jpg', 2, 5, 'Y', SYSDATE);
------------------------------------------------ BOOTH TABLE END ------------------------------------------------------
commit;