-------------------------------------------------PRODUCT TABLE START------------------------------------------------------------
DROP TABLE PRODUCT CASCADE CONSTRAINTS;
DROP SEQUENCE SEQ_PNO;

CREATE SEQUENCE SEQ_PNO
NOCACHE;

CREATE TABLE "PRODUCT" (
	"PRODUCT_NO"	NUMBER		PRIMARY KEY,
	"BOOTH_NO"	NUMBER		NOT NULL,
	"PRODUCT_NAME"	VARCHAR2(100)		NOT NULL,
	"PRODUCT_DETAIL"	VARCHAR2(4000)		NOT NULL,
	"PRODUCT_STOCK"	NUMBER		NOT NULL,
	"PRODUCT_STATUS"	VARCHAR2(1)	DEFAULT 'Y'	NOT NULL,
	"PRODUCT_PRICE"	NUMBER		NOT NULL,
	"PRODUCT_IMG_ON"	VARCHAR2(200),
	"PRODUCT_IMG_FP"	VARCHAR2(200)		NOT NULL,
    "PRODUCT_ENROLLDATE" DATE DEFAULT SYSDATE NOT NULL,
	FOREIGN KEY (BOOTH_NO) REFERENCES BOOTH (BOOTH_NO)
);

--코멘트 추가
COMMENT ON COLUMN "PRODUCT"."PRODUCT_NO" IS '상품번호';
COMMENT ON COLUMN "PRODUCT"."BOOTH_NO" IS '부스고유번호';
COMMENT ON COLUMN "PRODUCT"."PRODUCT_NAME" IS '상품이름';
COMMENT ON COLUMN "PRODUCT"."PRODUCT_DETAIL" IS '상품상세';
COMMENT ON COLUMN "PRODUCT"."PRODUCT_STOCK" IS '상품재고';
COMMENT ON COLUMN "PRODUCT"."PRODUCT_STATUS" IS '상품상태(Y/N) 품절 등';
COMMENT ON COLUMN "PRODUCT"."PRODUCT_PRICE" IS '상품가격';
COMMENT ON COLUMN "PRODUCT"."PRODUCT_IMG_ON" IS '상품사진 파일 원본명';
COMMENT ON COLUMN "PRODUCT"."PRODUCT_IMG_FP" IS '상품사진 파일 경로';


-- 더미 데이터 추가
INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 1, 'Midnight Musk And Amber Cologne', '하늘에 어둠이 깔릴 즈음,
관능적인 머스크와 앰버의 따뜻함이 어우러지고 주니퍼가 향을 완성해 줍니다.
고혹적인 향이 선사하는 황홀감을 즐겨보세요.', 10, 'Y', 220000, 'jmlpro.png', 'resources/uploadFiles/jmlpro.png', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 2, '스펠 온 유 (SPELL ON YOU)', '관능적이고도 경쾌한 향의 조화가
사랑의 황홀경으로 빠져들게 만드는 매력적인 아이리스
세상 그 무엇보다도 짜릿한 열정적인 사랑.
관능과 도발 사이를 넘나드는 기분 좋은 긴장감에서 영감을 받아
수석 조향사 자크 카발리에 벨투뤼가 선보이는 낭만적이고 장난기 가득하며
피부에 자연스럽게 스며드는 향.
매혹적인 여성미를 상징하는 고귀한 꽃의 이중성을 찬양하며
플로렌스산 아이리스 팔리다에 바치는 찬가.
눈부시고 풍성한 장미와 삼박 자스민에 보랏빛 향을 드리운 후
달콤한 아카시아 플라워를 만나 파우더리한 향을 자아내는 아이리스.
고혹적인 사랑과 은밀한 감각으로부터 흘러나온
잊을 수 없는 후렴구처럼 최면을 걸듯 황홀함을 선사하는 향수.', 5, 'Y', 410000, 'louis2.png', 'resources/uploadFiles/louis2.png', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 3, 'BOIS DORMANT 브아 도르망', '브아 도르망은 에디 슬리먼(HEDI SLIMANE)이 디자이너로서 활동하며
계속해서 선보여 온 잉글리시 더블 브레스트 플란넬 블레이저의 고급스러운 편안함,
그리고 클래식하고 절제된 구조를 떠오르게 합니다.

블랙 타이의 낮 버전인 섬세하고 우디한 이 향수는
파우더리 코롱의 바랜 듯한 향과 만나 더욱 풍성한 매력을 선사합니다.

베르가못, 주니퍼, 화이트 오리스 버터, 시더, 베티버.', 12, 'Y', 360000, 'celine2.png', 'resources/uploadFiles/celine2.png', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 3, 'RIMBAUD 랭보', '유년기와 성인기 그 사이 어딘가 금방이라도 끊어질 듯한 긴장감을 연상시키는 듯,
네오 클래식 라벤더의 산뜻한 노트 위에 아이리스의 파우더리한 베일이 섬세하게 내려앉습니다.

라벤더, 네롤리, 오리스 버터, 위트 어코드, 머스크, 바닐라 노트.', 15, 'Y', 360000, 'celine3.png', 'resources/uploadFiles/celine3.png', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 2, '쾨르 바텅 (COEUR BATTANT)', '인생의 소용돌이 속으로 이끄는 신선한 배와 새하얀 꽃송이 마음의 소리에 귀를 기울이고
매 순간을 열정을 품고 살아갈 수 있도록
감정의 물결이 마음을 휩쓸고 지나가는 듯한 기분을 선사하는 쾨르 바텅을 만나보세요.
수석 조향사 자크 카발리에 벨투뤼는
본능적인 열정이 풍부하게 담긴 향에 청량한 배를 한 입 베어 물었을 때
느껴지는 달콤함을 더해 인생의 즐거움을 선보입니다.
햇살 가득한 이집트산 자스민과 감각을 일깨우는
일랑일랑의 강한 울림이 불러일으키는 짙은 유혹을 느껴보세요.
파출리가 감각적인 향의 조합에 더욱 깊은 매력을 더해줍니다.
신선함과 관능미 사이 어딘가에서 팽팽한 줄다리기가
계속되는 듯한 강렬한 개성을 지닌 향수를 확인해보세요.
향수 파운틴이 구비된 매장에서 리필 가능한 아이템입니다.', 8, 'Y', 410000, 'louis3.jpg', 'resources/uploadFiles/louis3.jpg', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 1, 'Orange Bitters Cologne 오렌지 비터스 코롱', '과즙이 가득한 달콤한 오렌지
그리고 신선함이 넘치는 만다린의 두 가지의 상큼한 시트러스 향이 서로 어우러진 향.
풍미 넘치는 비터 오렌지에 감미로운 프룬 향이 어우러지고,
풍성한 샌달우드와 앰버의 향이 관능적인 여운을 남겨줍니다.', 20, 'Y', 220000, 'jml2.jpg', 'resources/uploadFiles/jml2.jpg', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 1, 'English Pear And Freesia Cologne 잉글리쉬 페어 앤 프리지아 코롱', '가을의 정수.
화이트 프리지아 부케향에 이제 막 익은 배의 신선함을 입히고
호박, 파출리, 우디향으로 은은함을 더했습니다.', 22, 'Y', 211000, 'jml3.jpg', 'resources/uploadFiles/jml3.jpg', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 2, '랩소디', '무한하게 펼쳐진 수평선을 비추는 세련된 시프레.
무한대로 확장하는 수평선이 있는 그곳에서 시작하는 특별한 여정.
매혹적이고 가슴 뛰는 순간.
모든 것이 시작되고, 모든 것이 생명을 다시 얻는 영원한 후각의 연금술.
수석 조향사 자크 카발리에 벨투뤼가 가장 정교한 조향법으로 DNA를 격상시킨 새로운 시프레 향.
일랑일랑과 빛나는 자스민 그란디플로룸의 아름다운 조화 및 빛에 둘러싸여 더욱 아름답게 변모하는 파촐리.
명암의 대비를 한층 강조하는 우디 노트와 베티버.
푸르른 자연의 빛을 더욱 강렬하게 하는 싱그럽고 맑은 마테 향을 품은 정교하게 조향된 퍼퓸.
우아함의 진수.

위대한 두 창작자의 조우를 바탕으로 향기의 정수만을 담아낸 다섯 가지의 특별한 향수를 선보이는
루이 비통 레 젝스트레 콜렉시옹의 랩소디.
자크 카발리에 벨투뤼가 대담하고 유려한 손길로 재창조한 퍼퓸 엑스트레.
역사상 가장 위대한 건축가 중 하나인 프랭크 게리의 첫 향수병 디자인.
마크 뉴슨의 오리지널 디자인의 직선을 곡선화한 실루엣이 특징.
투명한 장막이 공중에서 부유하며 솟아오르는 듯한 조각적인 장식.
손으로 연마하여 완성한 바람에 흩날리는 꽃송이의 모습을 닮은 금속 소재 뚜껑.', 7, 'Y', 780000, 'louis4.jpg', 'resources/uploadFiles/louis4.jpg', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 3, 'PARADE 파라드 오 드 퍼퓸', '환한 햇빛이 내려쬐는 듯한 네롤리와 베르가못 노트로 시작한 파라드는
자유로우면서도 섬세한 머스크와 오크 모스의 조화로움이 이어지고,
중독적이면서도 파우더리한 잔향으로 우아한 흔적을 남깁니다.

베르가못, 네롤리, 베티버, 머스크, 오크 모스.', 17, 'Y', 530000, 'celine4.jpg', 'resources/uploadFiles/celine4.jpg', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 2, '시티 오브 스타 (CITY OF STARS)', '황혼부터 새벽까지 마법에 휩싸이는 LA의 밤을 향한 찬사
하늘을 수놓은 별과 거리의 화려한 조명이 찬란하게 빛나는 LA의 밤을 예찬하며
수석 조향사 자크 카발리에 벨투뤼가 선보이는 시티 오브 스타.
어둠이 내리면 관능적인 향기를 타고 솟구치는 도시의 불빛.

수천 개의 전구처럼 반짝이는 레몬, 블러드 오랑주, 레드 만다린, 베르가못, 라임의 향연.

시트러스 향이 춤추듯 소용돌이를 이루다가 관능적인 티아르 꽃향기로 점차 스며드는 향.
아침 햇살과 함께 흩어지는 열정을 상징하는 파우더리한 머스크 향에 온기를 더하는 고귀한 샌달우드.
별들의 도시에 드리운 밤을 한 폭의 그림처럼 생생하게 묘사한 향수.
향수 파운틴이 구비된 매장에서 리필 가능한 아이템.', 5, 'Y', 410000, 'louis5.jpg', 'resources/uploadFiles/louis5.jpg', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 4, '리브르 르 퍼퓸', '대담한 리브르의 향에 진저와 사프란의 악센트가 더해진
강렬한 스파이시 플로럴 향수입니다', 21, 'Y', 197000, 'ysl2.png', 'resources/uploadFiles/ysl2.png', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 4, '리브르 오 드 빠르펭', '여성들을 더 대담하고 자유롭게 할 입생로랑의 아이코닉 향수.
깨끗한 라벤더와 관능적인 오렌지 블라썸의 완벽한 만남으로 시작되어
은은한 파우더리 머스크 잔향으로 강렬한 여운을 남기는 플로럴 라벤더 향수 입니다.
리브르 바틀은 비대칭 컷과 입생로랑 카산드르 골드 로고를 트위스트 하여
대담한 오버사이즈 꾸뛰르 액세서리로 완성되었습니다.', 18, 'Y', 175000, 'ysl3.jpg', 'resources/uploadFiles/ysl3.jpg', SYSDATE);

INSERT INTO PRODUCT VALUES (SEQ_PNO.NEXTVAL, 2, '애프터눈 스윔 (AFTERNOON SWIM)', '강렬한 오렌지가 안내하는 즐거움으로의 항해.
어느 뜨거운 여름날 뛰어든 감각의 바닷속에서 피부를 적셔 오는 파도의 강렬한 에너지.
수석 조향사 자크 카발리에 벨투뤼가 각별한 애정을 가진 시트러스에 바치는 오마주.

비타민이 폭발하듯 과즙으로 가득 찬 희귀한 시칠리아산 오렌지에 기품을 담아 완성한 향수.
기쁨의 파도를 머금은 베르가못이 짙게 밀려드는 만다린과 대조를 이루는 싱그러운 향기.

캘리포니아 출신 예술가 알렉스 이스라엘이 콜로뉴 퍼퓸의 색채를 보완해 달라는
메종 루이 비통의 요청을 받고 디자인한 창조적인 빛의 향수병.
끝나지 않는 여름을 기념하며 생기 넘치는 색상을 바탕으로 탄생시킨 경쾌한 디자인.', 3, 'Y', 410000, 'louis6.png', 'resources/uploadFiles/louis6.png', SYSDATE);

------------------------------------------------ PRODUCT TABLE END ------------------------------------------------------
commit;