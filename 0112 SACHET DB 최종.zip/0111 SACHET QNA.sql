---------------------------------------------------------QNA TABLE START---------------------------------------------
---------------------------------------STATUS 삭제---------------------------------------
DROP TABLE "QNA"

DROP SEQUENCE SEQ_QNO;

CREATE SEQUENCE SEQ_QNO
START WITH 1
MAXVALUE 9999
NOCACHE;

CREATE TABLE "QNA" (
	"QNA_NO"	NUMBER		PRIMARY KEY,
	"QNA_CATE"	NUMBER		NOT NULL,
	"QNA_TITLE"	VARCHAR2(500)		NOT NULL,
	"QNA_CONTENT"	VARCHAR2(4000)		NOT NULL
);

COMMENT ON COLUMN "QNA"."QNA_NO" IS '질의응답 글번호';

COMMENT ON COLUMN "QNA"."QNA_CATE" IS '질의응답 카테고리(EX. 1.회원정보 관련 / 2. 예매, 구매 관련 / 3. 기업 관련 / 4. 기타 등)';

COMMENT ON COLUMN "QNA"."QNA_TITLE" IS '질의응답 제목';

COMMENT ON COLUMN "QNA"."QNA_CONTENT" IS '질의응답 내용';

INSERT INTO QNA VALUES (SEQ_QNO.NEXTVAL,2,'온라인 예매 매진시 현장예매는 아예 불가능한가요','온라인 예매가 매진되어도 현장 예매분은 별도로 남겨두어 행사 기간동안 현장 티켓부스에서 구입가능합니다.다만 폐장시간 30분 이전까지만 입장권 구매가 가능합니다.');
INSERT INTO QNA VALUES (SEQ_QNO.NEXTVAL,2,'관람시간은 어떻게 되나요?','관람시간은 오전09:00~오후18:00입니다.');

INSERT INTO QNA VALUES (SEQ_QNO.NEXTVAL,2,'퇴장한 후에 재입장이 가능한가요?','당일에 한해서 동일 입장권 및 인식표(명찰)확인으로 재입장이 가능합니다.');
INSERT INTO QNA VALUES (SEQ_QNO.NEXTVAL,2,'음식물 반입이 가능한가요?','해외 바이어 및 관람객의 안전과 편의를 위하여 음식물 반입은 금지되어있습니다. 식사는 전시장 인근 편의시설을 이용하여 주시기 바랍니다.');

INSERT INTO QNA VALUES (SEQ_QNO.NEXTVAL,3,'참가 취소할 경우 어떤 불이익이 생기나요?','참가사가 당사자의 사정으로 인하여 신청한 전시면적의 사용을 전부 또는 일부를 취소하거나 거부하는 경우, 반드시 주최자에게 서면 통보를 하여야 하며, 다음에 정한 위약금 상당액을 참가 취소 후 10일 이내에 주최사에 지불하여야 합니다.
 
단, 기 납입된 전시준비비는 동 위약금으로 차감하고, 부족 시 추가 납입하여야 하고 잉여 시 반환합니다.
 
- 2017년 3월 10일 이전에 취소한 경우 : 총 전시준비비의 50%를 위약금으로 납부
 
- 2017년 5월 10일 이후에 취소한 경우 : 총 전시준비비의 80%를 위약금으로 납부
 
※위약금은 부가세가 포함되지 않은 금액이며, 세금계산서도 발행되지 않습니다.');