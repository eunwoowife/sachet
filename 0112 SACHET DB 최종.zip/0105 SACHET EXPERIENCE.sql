-------------------------------------------------EXPERIENCE TABLE START------------------------------------------------------------
-------------1229 EXPER_DATE를 NUMBER로 변경함.
-------------0103 누가 시퀀스를 1000번대부터 만들라해서 변경함.
DROP TABLE EXPERIENCE CASCADE CONSTRAINTS;
DROP SEQUENCE SEQ_ENO;

CREATE SEQUENCE SEQ_ENO
START WITH 1001
MAXVALUE 9999
NOCACHE;

CREATE TABLE "EXPERIENCE" (
	"EXPER_NO"	NUMBER		PRIMARY KEY,
	"BOOTH_NO"	NUMBER		NOT NULL,
	"EXPER_TIME"	NUMBER		NOT NULL,
    "EXPER_DATE"	NUMBER		NOT NULL,
	"EXPER_TITLE"	VARCHAR2(100)		NOT NULL,
	"EXPER_DETAIL"	VARCHAR2(4000)		NOT NULL,
	"EXPER_PRICE"	NUMBER		NOT NULL,
	"CAPACITY"	NUMBER		NOT NULL,
	"EXPER_IMG_ON"	VARCHAR2(200)		NOT NULL,
	"EXPER_IMG_FP"	VARCHAR2(200)		NOT NULL,
    "EXPER_ENROLLDATE" DATE DEFAULT SYSDATE NOT NULL,
    "EXPER_STATUS" VARCHAR2(1) DEFAULT 'Y'	NOT NULL,
FOREIGN KEY (BOOTH_NO) REFERENCES BOOTH (BOOTH_NO)
);

--코멘트 추가
COMMENT ON COLUMN "EXPERIENCE"."EXPER_NO" IS '체험번호';
COMMENT ON COLUMN "EXPERIENCE"."BOOTH_NO" IS '부스고유번호';
COMMENT ON COLUMN "EXPERIENCE"."EXPER_TIME" IS '체험시간(1타임~4타임)';
COMMENT ON COLUMN "EXPERIENCE"."EXPER_DATE" IS '체험일자';
COMMENT ON COLUMN "EXPERIENCE"."EXPER_TITLE" IS '체험이름';
COMMENT ON COLUMN "EXPERIENCE"."EXPER_DETAIL" IS '체험내용';
COMMENT ON COLUMN "EXPERIENCE"."EXPER_PRICE" IS '체험가격';
COMMENT ON COLUMN "EXPERIENCE"."CAPACITY" IS '수용인원';
COMMENT ON COLUMN "EXPERIENCE"."EXPER_IMG_ON" IS '체험사진 파일 원본명';
COMMENT ON COLUMN "EXPERIENCE"."EXPER_IMG_FP" IS '체험사진 파일 경로';
COMMENT ON COLUMN "EXPERIENCE"."EXPER_ENROLLDATE" IS '체험등록일';
COMMENT ON COLUMN "EXPERIENCE"."EXPER_STATUS" IS '체험상태(Y/N)';


-- 더미 데이터 추가
INSERT INTO EXPERIENCE VALUES (SEQ_ENO.NEXTVAL, 2, 2, 2, '루이비통 7향 1택 조향(30ml)', '7향 종류 : 
로즈 데 벙
에투알 필랑트
쾨르 바텅
아트라프 레브
마티에르 누와르
르 주르 스레브
외르 답상스', 100000, 30, 'louisExp.png', 'resources/uploadFiles/louisExp.png', SYSDATE, 'Y');

INSERT INTO EXPERIENCE VALUES (SEQ_ENO.NEXTVAL, 1, 1, 1, 'Fresh Fig And Cassis Diffuser 만들기(100ml)', '정원에서 즐기는 한가로운 아침 식사.
잘 익은 무화과 향이 포근한 아침 햇살을 받아 돌담을 뒤덮습니다.
신선한 공기가 정원을 가득 채우고,
나뭇잎과 나무들의 흔적을 여기저기 남깁니다.', 70000, 25, 'jmlExp.jpg', 'resources/uploadFiles/jmlExp.jpg', SYSDATE, 'Y');

INSERT INTO EXPERIENCE VALUES (SEQ_ENO.NEXTVAL, 1, 1, 3, '컬러 캡 제작하기(6색 1택)', '6색 종류 : 
Dark Green Coloured Cap
Yellow Gold Coloured Cap
Dark Blue Coloured Cap
Red Coloured Cap
Dark Pink Coloured Cap
Blossom Pink Coloured Cap', 6000, 30, 'joExp3.jpg', 'resources/uploadFiles/joExp3.jpg', SYSDATE, 'Y');
------------------------------------------------ EXPERIENCE TABLE END ------------------------------------------------------
commit;